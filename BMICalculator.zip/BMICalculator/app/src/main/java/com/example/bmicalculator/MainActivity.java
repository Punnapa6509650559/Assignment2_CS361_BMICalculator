package com.example.bmicalculator;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText weightInput, heightInput;
    private TextView bmiResult, bmiCategory;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // เชื่อมต่อกับ views
        weightInput = findViewById(R.id.etWeight);
        heightInput = findViewById(R.id.etHeight);
        bmiResult = findViewById(R.id.tvBmiResult);
        bmiCategory = findViewById(R.id.tvBmiCategory);
        calculateButton = findViewById(R.id.btnCalculate);

        // กดปุ่มเพื่อคำนวณ BMI
        calculateButton.setOnClickListener(v -> calculateBMI());
    }

    private void calculateBMI() {
        String weightStr = weightInput.getText().toString();
        String heightStr = heightInput.getText().toString();

        if (!weightStr.isEmpty() && !heightStr.isEmpty()) {
            double weight = Double.parseDouble(weightStr);
            double height = Double.parseDouble(heightStr) / 100;  // เปลี่ยนเป็นเมตร

            double bmi = weight / (height * height);
            DecimalFormat df = new DecimalFormat("#.##");
            bmiResult.setText(df.format(bmi));

            // จัดประเภท BMI
            String category;
            if (bmi < 18.5) {
                category = getString(R.string.underweight);
            } else if (bmi < 24.9) {
                category = getString(R.string.normal);
            } else if (bmi < 29.9) {
                category = getString(R.string.overweight);
            } else {
                category = getString(R.string.obese);
            }
            bmiCategory.setText(category);
        }
    }
}
